﻿namespace MyFirstBlazor.Shared
{
  public class Product
  {
    public string Name { get; set; }
    public string Description { get; set; }
    public decimal UnitPrice { get; set; }
  }
}
