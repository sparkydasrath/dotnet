﻿(function () {
  window.blazorFocus = {
    set: (element) => { element.focus(); }
  };
})();
